<?php
// @codingStandardsIgnoreFile
// Silence is golden.