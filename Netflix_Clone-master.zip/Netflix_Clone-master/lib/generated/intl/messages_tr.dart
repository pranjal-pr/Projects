// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a tr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'tr';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "a1": MessageLookupByLibrary.simpleMessage("SSS"),
        "a2": MessageLookupByLibrary.simpleMessage("Yatırımcı İlişkileri"),
        "a3": MessageLookupByLibrary.simpleMessage("Kullanım Koşulları"),
        "a4": MessageLookupByLibrary.simpleMessage("Bize Ulaşın"),
        "akl": MessageLookupByLibrary.simpleMessage(
            "Akıllı TV, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray oynatıcılar ve daha fazlasında seyredin."),
        "b1": MessageLookupByLibrary.simpleMessage("Yardım Merkezi"),
        "b2": MessageLookupByLibrary.simpleMessage("İş İmkanları"),
        "b3": MessageLookupByLibrary.simpleMessage("Gizlilik"),
        "b4": MessageLookupByLibrary.simpleMessage("Hız Testi"),
        "bas": MessageLookupByLibrary.simpleMessage("Başlayın"),
        "c1": MessageLookupByLibrary.simpleMessage("Hesap"),
        "c2": MessageLookupByLibrary.simpleMessage("Hediye Kartı Kullan"),
        "c3": MessageLookupByLibrary.simpleMessage("Çerez Tercihleri"),
        "c4": MessageLookupByLibrary.simpleMessage("Yasal Hükümler"),
        "cev": MessageLookupByLibrary.simpleMessage(
            "Çevrimdışı izlemek için \niçerikleri indirin."),
        "coc": MessageLookupByLibrary.simpleMessage(
            "Çocuklarınız için \nprofiller oluşturun."),
        "d1": MessageLookupByLibrary.simpleMessage("Medya Merkezi"),
        "d2": MessageLookupByLibrary.simpleMessage("İzleme Yolları"),
        "d3": MessageLookupByLibrary.simpleMessage("Kurumsal Bilgiler"),
        "d4": MessageLookupByLibrary.simpleMessage("Sadece Netflix\'te"),
        "eks": MessageLookupByLibrary.simpleMessage(
            "Ekstra ücret ödemeden telefonda, tablette, bilgisayarda, televizyonda sınırsız film ve dizi izleyin."),
        "ens": MessageLookupByLibrary.simpleMessage(
            "En sevdiğiniz içerikleri kolayca kaydedin ve her zaman izleyecek bir şeyleriniz olsun."),
        "eps": MessageLookupByLibrary.simpleMessage("E-posta adresi"),
        "ist": MessageLookupByLibrary.simpleMessage(
            "İstediğiniz yerde izleyin. İstediğiniz zaman iptal edin."),
        "izl": MessageLookupByLibrary.simpleMessage(
            "İzlemeye hazır mısınız? Üyelik oluşturmak veya üyeliğinize erişmek için e‑posta adresinizi girin."),
        "net": MessageLookupByLibrary.simpleMessage("Netflix Türkiye"),
        "ot": MessageLookupByLibrary.simpleMessage("Oturum Aç"),
        "s1": MessageLookupByLibrary.simpleMessage("Netflix nedir?"),
        "s2":
            MessageLookupByLibrary.simpleMessage("Netflix\'in maliyeti nedir?"),
        "s3": MessageLookupByLibrary.simpleMessage("Nerede izleyebilirim?"),
        "s4": MessageLookupByLibrary.simpleMessage("Nasıl iptal ederim?"),
        "s5": MessageLookupByLibrary.simpleMessage(
            "Netflix\'de neler izleyebilirim?"),
        "s6": MessageLookupByLibrary.simpleMessage(
            "Netflix çocuklar için uygun mudur?"),
        "sik": MessageLookupByLibrary.simpleMessage("Sıkça Sorulan Sorular"),
        "sin": MessageLookupByLibrary.simpleMessage(
            "Sınırsız film, dizi ve çok \ndaha fazlası."),
        "sor": MessageLookupByLibrary.simpleMessage(
            "Sorularınız mı var? 0850-390-7444 numaralı telefonu arayın"),
        "tel": MessageLookupByLibrary.simpleMessage(
            "Televizyonunuzda \nizleyebilirsiniz."),
        "turk": MessageLookupByLibrary.simpleMessage("Türkçe"),
        "uye": MessageLookupByLibrary.simpleMessage(
            "Üyeliğinize dâhil olan bu ücretsiz deneyim sayesinde çocuklarınız, sadece onlara özel bir alanda en sevdikleri karakterlerle maceralara atılabilir."),
        "yer": MessageLookupByLibrary.simpleMessage(
            "İstediğiniz her yerde \nizleyin.")
      };
}
