# netflix_clone

A new Flutter project.

# Run

In order to run your application, type:

<!--START_SECTION:waka-->
```text
  $ cd netflix_clone
```
<!--END_SECTION:waka-->


<!--START_SECTION:waka-->
```text
  $ flutter run
```
<!--END_SECTION:waka-->

Your application code is in netflix_clone\lib\main.dart.

# Assets/Videos


<img src="https://media.giphy.com/media/xVqeJsJ1z5kF9xeXIR/giphy.gif"/>

![net](https://user-images.githubusercontent.com/57798484/146642244-6b2a012b-825b-4c39-a08c-2bd387e841fa.PNG)
![neten](https://user-images.githubusercontent.com/57798484/146642247-a89a1102-31c4-4e07-9c1c-f3ef74250637.PNG)




https://user-images.githubusercontent.com/57798484/146642269-d87e7d24-9d9d-4382-82f4-b6a7f35c500d.mp4




## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
