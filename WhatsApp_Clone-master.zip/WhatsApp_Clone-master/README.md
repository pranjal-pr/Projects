
# whatsapp_clone

A new Flutter project.
# Run
Mobile & Desktop

<!--START_SECTION:waka-->
```text
  $ Platform.isAndroid || Platform.isIOS ? Mobile() : MyHomePage(),
```
<!--END_SECTION:waka-->

In order to run your application, type:




<!--START_SECTION:waka-->
```text
  $ cd whatsapp_clone
```
<!--END_SECTION:waka-->


<!--START_SECTION:waka-->
```text
  $ flutter run
```
<!--END_SECTION:waka-->
Shortcut whatsapp_clone.exe.
<!--START_SECTION:waka-->
```text
  $ whatsapp_clone\build\windows\runner\Debug/whatsapp_clone.exe
```
<!--END_SECTION:waka-->

Your application code is in whatsapp_clone\lib\main.dart.

# Assets/Videos



<p float="left">

  <img src="https://user-images.githubusercontent.com/57798484/158177835-4eb22bbc-3bca-4380-abf4-f1e7628995ac.png" width="400" />
  <img src="https://user-images.githubusercontent.com/57798484/158177842-f5cc2c0a-c746-42ea-bf84-b47572dc0adb.png" width="400"/>
</p>

<p float="left">

  <img src="https://user-images.githubusercontent.com/57798484/158177845-1ddc858d-9574-4f7f-b542-dd9ac370bc2c.png" width="400" />
  <img src="https://user-images.githubusercontent.com/57798484/158177831-61c0d9db-4d46-4e9e-9d5b-12de6ed95354.png" width="400"/>
</p>






![Ekran Görüntüsü (209)](https://user-images.githubusercontent.com/57798484/158177729-aeb00dda-711b-4749-b4cf-21f9e5437b3d.png)
![Ekran Görüntüsü (211)](https://user-images.githubusercontent.com/57798484/158177738-73217678-9c0b-4e2f-8976-9daa65aa6da4.png)
![Ekran Görüntüsü (210)](https://user-images.githubusercontent.com/57798484/158177736-2de7656b-a8a8-450b-8aa6-8567455eadd3.png)


https://user-images.githubusercontent.com/57798484/158178544-f8ea3db5-473d-4328-afc7-c4a9c7e06adf.mp4


https://user-images.githubusercontent.com/57798484/158178553-06ecea7c-c691-48e2-ad8c-63c98dbcab54.mp4




## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
