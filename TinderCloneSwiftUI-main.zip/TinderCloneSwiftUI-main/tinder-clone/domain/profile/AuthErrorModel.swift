//
//  AuthErrorModel.swift
//  tinder-clone
//
//  Created by Alejandro Piguave on 8/6/23.
//

import Foundation

struct AuthErrorModel : Error{
    let message: String
}
