//
//  AuthTypeModel.swift
//  tinder-clone
//
//  Created by Alejandro Piguave on 8/6/23.
//

import Foundation

enum AuthTypeModel {
    case newUser
    case existingUser
}
