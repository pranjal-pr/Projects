//
//  Constants.swift
//  tinder-clone
//
//  Created by Alejandro Piguave on 18/1/22.
//

import Foundation

class Constants{
    static let genderOptions = ["man", "woman"] //Simplified for the sake of the app, same with sexual orientation
}
