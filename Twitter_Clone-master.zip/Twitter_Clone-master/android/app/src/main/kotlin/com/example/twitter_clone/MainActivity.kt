package com.example.twitter_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
