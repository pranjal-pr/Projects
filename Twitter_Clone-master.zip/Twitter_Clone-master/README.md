
# twitter_clone

A new Flutter project.

# Run

In order to run your application, type:

web/index.html

<!--START_SECTION:waka-->
```text
  <base href="https://ersangvnc.github.io/Twitter_Clone_Web/">
  <!-- <base href="/"> -->
```
<!--END_SECTION:waka-->

Change

<!--START_SECTION:waka-->
```text
   <!-- <base href="https://ersangvnc.github.io/Twitter_Clone_Web/"> -->
   <base href="/">
```
<!--END_SECTION:waka-->


<!--START_SECTION:waka-->
```text
  $ cd twitter_clone
```
<!--END_SECTION:waka-->


<!--START_SECTION:waka-->
```text
  $ flutter run
```
<!--END_SECTION:waka-->

Your application code is in twitter_clone\lib\main.dart.

# Assets/Videos



![Ekran Görüntüsü (228)](https://user-images.githubusercontent.com/57798484/161112089-c99be962-163c-41bd-9ef7-3d0d594a06e9.png)
![Ekran Görüntüsü (229)](https://user-images.githubusercontent.com/57798484/161112094-0120a7a4-d1db-440d-8f0a-53e468be32f3.png)
![Ekran Görüntüsü (230)](https://user-images.githubusercontent.com/57798484/161112099-b4be3149-dc98-4a3a-a9d7-1a482ab7d714.png)
![Ekran Görüntüsü (231)](https://user-images.githubusercontent.com/57798484/161112104-2f5aaa24-45c1-4c65-94b7-4625d4c8f9f1.png)
![Ekran Görüntüsü (232)](https://user-images.githubusercontent.com/57798484/161112105-857b34a3-3106-4b2a-a9fc-18e7aee2d274.png)
![Ekran Görüntüsü (233)](https://user-images.githubusercontent.com/57798484/161112107-7ea02d22-fad3-4209-9b28-f0e7f1338fbe.png)
![Ekran Görüntüsü (234)](https://user-images.githubusercontent.com/57798484/161112108-7277d727-b2d6-4159-aeb5-d1195e5396ef.png)
![Ekran Görüntüsü (235)](https://user-images.githubusercontent.com/57798484/161112110-4bd11688-5c67-4481-9daf-f8730bfa0dd6.png)






https://user-images.githubusercontent.com/57798484/161112157-29f8711b-f283-459f-8372-d60045064e18.mp4






## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
